import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from matplotlib import pyplot as plt


class BOVHelpers:
    def __init__(self, n_clusters=500, clf=SVC()):
        self.n_clusters = n_clusters
        self.kmeans_obj = KMeans(n_clusters=n_clusters)
        self.kmeans_ret = None
        self.descriptor_vstack = None
        self.mega_histogram = None
        self.clf = clf
        self.train_labels = None
        self.name_dict = {}

    def cluster(self):

        self.kmeans_ret = self.kmeans_obj.fit_predict(self.descriptor_vstack)

    def develop_vocabulary(self, n_images, descriptor_list):

        self.mega_histogram = np.array([np.zeros(self.n_clusters) for i in range(n_images)])
        old_count = 0

        for i in range(len(descriptor_list)):
            l = len(descriptor_list[i])
            for j in range(l):
                idx = self.kmeans_ret[old_count + j]
                self.mega_histogram[i][idx] += 1
            old_count += l
            # print "Vocabulary Histogram Generated"

    def standardize(self, std=None):

        if std is None:
            self.scale = StandardScaler().fit(self.mega_histogram)
            self.mega_histogram = self.scale.transform(self.mega_histogram)
        else:
            print "STD not none. External STD supplied"
            self.mega_histogram = std.transform(self.mega_histogram)

    def formatND(self, l):
        vStack = np.array(l[0])
        for remaining in l[1:]:
            vStack = np.vstack((vStack, remaining))
        self.descriptor_vstack = vStack.copy()
        return vStack

    def train(self, train_labels):

        self.train_labels = train_labels.copy()
        self.clf.fit(self.mega_histogram, train_labels)
        return self.clf

    def predict(self, iplist):
        predictions = self.clf.predict(iplist)
        return predictions

    def plotHist(self, vocabulary=None):
        print "Plotting histogram"
        if vocabulary is None:
            vocabulary = self.mega_histogram

        x_scalar = np.arange(self.n_clusters)
        y_scalar = np.array([abs(np.sum(vocabulary[:, h], dtype=np.int32)) for h in range(self.n_clusters)])

        print y_scalar

        plt.bar(x_scalar, y_scalar)
        plt.xlabel("Visual Word Index")
        plt.ylabel("Frequency")
        plt.title("Complete Vocabulary Generated")
        plt.xticks()
        plt.xticks(x_scalar + 0.4, x_scalar)
        plt.show()
