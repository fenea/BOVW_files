import cv2
class Sift:
    def __init__(self, nfeatures=100):
        self.sift_object = cv2.xfeatures2d.SIFT_create(nfeatures=nfeatures)

    def features(self, image):
        keypoints, descriptors = self.sift_object.detectAndCompute(image, None)
        return [keypoints, descriptors]


class SurfHelper:
    def __init__(self, hessianThreshold=300, upright=True):
        self.surf_object = cv2.xfeatures2d.SURF_create(hessianThreshold=hessianThreshold, upright=upright)

    def features(self, image):
        keypoints, descriptors = self.surf_object.detectAndCompute(image, None)
        return [keypoints, descriptors]


class HogHelper:
    def __init__(self):
        pass

    def features(self, image):
        descriptors = cv2.HOGDescriptor().compute(img=image)
        return [descriptors]


class Brief:
    def __init__(self):
        self.star = cv2.xfeatures2d.SURF_create()
        self.brief = cv2.xfeatures2d.BriefDescriptorExtractor_create()

    def features(self, image):

        kp = self.star.detect(image, None)

        keypoints, descriptors = self.brief.compute(image, kp)
        return [keypoints, descriptors]

class Orb:
    def __init__(self):
        self. orb = cv2.ORB_create()
    def features(self, img):

        kp = self.orb.detect(img, None)
        kp, des = self.orb.compute(img, kp)
        return [kp, des]


class FreakHelper:
    def __init__(self):
        self.freak_object = cv2.xfeatures2d.FREAK_create()
        self.surf_object = cv2.xfeatures2d.SURF_create(hessianThreshold=200, upright=True)

    def features(self, image):
        kp = self.surf_object.detect(image, None)
        keypoints, descriptors = self.freak_object.compute(image=image, keypoints=kp)
        return [keypoints, descriptors]


class FastHelper:
    def __init__(self, hessianThreshold=200, upright=True):
        self.fast_object = cv2.FastFeatureDetector_create()
        self.surf_object = cv2.xfeatures2d.SURF_create(hessianThreshold=hessianThreshold, upright=upright)

    def features(self, image):
       # kp = self.surf_object.detect(image, None)
        keypoints, descriptors = self.fast_object(image=image)
        return [keypoints, descriptors]
