import os
print("Starting run ")
#os.system("python cnn_multilayer.py -r 0.2 -n 3 -s 1000")
#os.system("python cnn_multilayer.py -r 0.3 -n 3")


#ratio
#os.system("python cnn_multilayer.py -r 0.6")
#os.system("python cnn_multilayer.py -r 0.7")
#os.system("python cnn_multilayer.py -r 0.8")

#size



os.system("python cnn_multilayer.py -p ../../datasets2/self_made_dataset -he 180 -w 180 -n 3 -s 500")

os.system("python cnn_multilayer.py -p ../../datasets2/self_made_dataset -he 180 -w 180 -n 5 -s 500")
os.system("python cnn_multilayer.py -p ../../datasets2/self_made_dataset -he 180 -w 180 -n 5 -s 1000")

os.system("python cnn_multilayer.py -p ../../datasets2/self_made_dataset -he 180 -w 180 -n 10 -s 2500")
'''
os.system("python cnn_multilayer.py -n 50 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 2000")
os.system("python cnn_multilayer.py -n 50 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 3000")
os.system("python cnn_multilayer.py -n 50 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 4000")
os.system("python cnn_multilayer.py -n 50 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 5000")

os.system("python cnn_multilayer.py -n 70 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 4000")
os.system("python cnn_multilayer.py -n 70 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 5000")

os.system("python cnn_multilayer.py -n 80 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 3000")
os.system("python cnn_multilayer.py -n 80 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 5000")
os.system("python cnn_multilayer.py -n 80 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 7000")

os.system("python cnn_multilayer.py -n 100 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 3000")
os.system("python cnn_multilayer.py -n 100 -p ../../datasets2/caltech_256 -he 100 -w 100")
os.system("python cnn_multilayer.py -n 100 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 7000")
os.system("python cnn_multilayer.py -n 100 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 8000")


os.system("python cnn_multilayer.py -n 150 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 8000")
os.system("python cnn_multilayer.py -n 200 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 8000")
os.system("python cnn_multilayer.py -n 200 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 10000")

os.system("python cnn_multilayer.py -n 250 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 8000")
os.system("python cnn_multilayer.py -n 250 -p ../../datasets2/caltech_256 -he 100 -w 100 -s 15000")


os.system("python cnn_multilayer.py -n 100 -p ../../datasets2/caltech_256 -he 200 -w 200")
os.system("python cnn_multilayer.py -n 100 -p ../../datasets2/caltech_256 -he 200 -w 200 -s 7000")
os.system("python cnn_multilayer.py -n 100 -p ../../datasets2/caltech_256 -he 200 -w 200 -s 8000")


os.system("python cnn_multilayer.py -n 150 -p ../../datasets2/caltech_256 -he 200 -w 200 -s 8000")
os.system("python cnn_multilayer.py -n 200 -p ../../datasets2/caltech_256 -he 200 -w 200 -s 8000")
os.system("python cnn_multilayer.py -n 200 -p ../../datasets2/caltech_256 -he 200 -w 200 -s 10000")

os.system("python cnn_multilayer.py -n 250 -p ../../datasets2/caltech_256 -he 200 -w 200 -s 8000")
os.system("python cnn_multilayer.py -n 250 -p ../../datasets2/caltech_256 -he 200 -w 200 -s 15000")


os.system("python cnn_multilayer.py -he 180 -w 180 -n 20 -s 2000")
os.system("python cnn_multilayer.py -he 180 -w 180 -n 20 -s 10000")
os.system("python cnn_multilayer.py -he 180 -w 180 -n 20 -s 500")
os.system("python cnn_multilayer.py -he 180 -w 180 -n 20 -s 5000")

os.system("python cnn_multilayer.py -he 50 -w 50")
os.system("python cnn_multilayer.py -he 80 -w 80")
os.system("python cnn_multilayer.py -he 100 -w 100")
os.system("python cnn_multilayer.py -he 150 -w 150")
'''



'''
#classes
os.system("python cnn_multilayer.py -n 3")
os.system("python cnn_multilayer.py -n 5")
os.system("python cnn_multilayer.py -n 15")
os.system("python cnn_multilayer.py -n 20")

os.system("python cnn_multilayer.py -n 5 -p ../../datasets2/corel-categories -he 100 -w 100")
os.system("python cnn_multilayer.py -n 10 -p ../../datasets2/corel-categories -he 100 -w 100")
os.system("python cnn_multilayer.py -n 20 -p ../../datasets2/corel-categories -he 100 -w 100")
os.system("python cnn_multilayer.py -n 30 -p ../../datasets2/corel-categories -he 100 -w 100")
os.system("python cnn_multilayer.py -n 50 -p ../../datasets2/corel-categories -he 100 -w 100")

os.system("python cnn_multilayer.py -n 60 -p ../../datasets2/corel-categories -he 100 -w 100")
os.system("python cnn_multilayer.py -n 70 -p ../../datasets2/corel-categories -he 100 -w 100")
os.system("python cnn_multilayer.py -n 80 -p ../../datasets2/corel-categories -he 100 -w 100")
os.system("python cnn_multilayer.py -n 90 -p ../../datasets2/corel-categories -he 100 -w 100")
'''

'''
os.system("python cnn_multilayer.py -n 5 -p ../../datasets2/caltech_101 -he 60 -w 60")
os.system("python cnn_multilayer.py -n 10 -p ../../datasets2/caltech_101 -he 60 -w 60")
os.system("python cnn_multilayer.py -n 20 -p ../../datasets2/caltech_101 -he 60 -w 60")
os.system("python cnn_multilayer.py -n 30 -p ../../datasets2/caltech_101 -he 60 -w 60")
os.system("python cnn_multilayer.py -n 50 -p ../../datasets2/caltech_101 -he 60 -w 60")
os.system("python cnn_multilayer.py -n 80 -p ../../datasets2/caltech_101 -he 60 -w 60")
os.system("python cnn_multilayer.py -n 100 -p ../../datasets2/caltech_101 -he 60 -w 60")
'''
'''
make_a_full_run('../../datasets2/GHIM20', ratio=0.6, classes_num=3, samples_per_epoch=500)

make_a_full_run('../../datasets2/GHIM20', ratio=0.6, classes_num=4, samples_per_epoch=500)

make_a_full_run('../../datasets2/GHIM20', ratio=0.7)
make_a_full_run('../../datasets2/GHIM20', ratio=0.8)
# size
make_a_full_run('../../datasets2/GHIM20', width=30, height=30)
make_a_full_run('../../datasets2/GHIM20', width=50, height=50)
make_a_full_run('../../datasets2/GHIM20', width=100, height=100)
make_a_full_run('../../datasets2/GHIM20', width=150, height=150)

# samples_per_epoch
make_a_full_run('../../datasets2/GHIM20', samples_per_epoch=1000)
make_a_full_run('../../datasets2/GHIM20', samples_per_epoch=3000)
make_a_full_run('../../datasets2/GHIM20', samples_per_epoch=5000)
make_a_full_run('../../datasets2/GHIM20', samples_per_epoch=7000)
make_a_full_run('../../datasets2/GHIM20', samples_per_epoch=10000)

# clases num
make_a_full_run('../../datasets2/GHIM20', classes_num=3)
make_a_full_run('../../datasets2/GHIM20', classes_num=5)
make_a_full_run('../../datasets2/GHIM20', classes_num=15)
make_a_full_run('../../datasets2/GHIM20', classes_num=20)
'''