import multiprocessing
import sys
import os
import sys, getopt
import argparse
import shutil
import time

import gc

#from git import Repo, Git
import cv2
from git import Repo
from keras.backend import clear_session, tf
from keras.engine.saving import load_model

from keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array
from keras import optimizers
from keras.models import Sequential
from keras.layers import Dropout, Flatten, Dense, Activation
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras import callbacks
import numpy as np
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix
import itertools
from keras import backend as K


tmp_dir = "tmp"


def get_the_list_of_subdirectories(parentPath):
    # get the list of folder names
    dirName = []
    for _, _dir, _ in os.walk(str(parentPath)):
        if len(_dir) > 0:
            dirName.append(_dir)
    return dirName[0]


class CNN:
    def __init__(self, samples_per_epoch=5000, classes_num=10, width=180, height=180):
        self.tmp_dir = "tmp"
        self.img_width = width
        self.img_height = height
        self.model_path = './models/model.h5'
        self.model_weights_path = './models/weights.h5'

        self.train_data_path = './tmp/train'
        self.validation_data_path = './tmp/test'

        self.title = "stats3"
        self.samples_per_epoch = samples_per_epoch
        self.classes_num = classes_num

    # get the list of all dir in the parent
    @staticmethod
    def get_the_list_of_subdirectories(parentPath):
        # get the list of folder names
        dirName = []
        for _, _dir, _ in os.walk(str(parentPath)):
            if len(_dir) > 0:
                dirName.append(_dir)
        return dirName[0]

    '''
    getting a dataset path, separates it into test and train, with the same folder names.
    :param ratio default 0.7 
    :param number of categories to be copied
    '''

    @staticmethod
    def separate_into_train_and_test(path, ratio=0.8, categories_to_copy=10):
        dirList = get_the_list_of_subdirectories(path)
        print(dirList)
        category_nr = 0
        for category in dirList:
            if category_nr == categories_to_copy:
                return
            train_dir = tmp_dir + '/train/' + category
            test_dir = tmp_dir + '/test/' + category

            try:
                os.stat(train_dir)
            except:
                os.makedirs(train_dir)
            try:
                os.stat(test_dir)
            except:
                os.makedirs(test_dir)

            imgCollection = next(os.walk(path + '/' + category))[2]
            nr_imgs = len(imgCollection)
            print(nr_imgs)
            for i in range(nr_imgs):

                if i < nr_imgs * ratio:
                    source = path + "/" + category + "/" + imgCollection[i]
                    dest = train_dir + "/" + imgCollection[i]
                    if source.endswith(".jpg"):
                        img = cv2.imread(source)
                        cv2.imwrite(dest, img)

                else:
                    source = path + "/" + category + "/" + imgCollection[i]
                    dest = test_dir + "/" + imgCollection[i]
                    if source.endswith(".jpg"):
                        img = cv2.imread(source)
                        cv2.imwrite(dest, img)
            category_nr += 1

    @staticmethod
    def resize_to_square(img):
        height, width, chanels = img.shape
        if height > width:
            new_image = img[0:width, 0:width]
        else:
            new_image = img[0:height, 0:height]
        return new_image
    @staticmethod
    def plot_confusion_matrix(cm, classes,
                              normalize=False,
                              title='Confusion matrix',
                              cmap=plt.cm.Blues):
        if normalize:
            cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
            print("Normalized confusion matrix")
        else:
            print('Confusion matrix, without normalization')

        print(cm)

        plt.imshow(cm, interpolation='nearest', cmap=cmap)
        plt.title(title)
        plt.colorbar()
        tick_marks = np.arange(len(classes))
        plt.xticks(tick_marks, classes, rotation=45)
        plt.yticks(tick_marks, classes)

        fmt = '.2f' if normalize else 'd'
        thresh = cm.max() / 2.
        for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
            plt.text(j, i, format(cm[i, j], fmt),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")

        plt.tight_layout()
        plt.ylabel('True label')
        plt.xlabel('Predicted label')

    '''
    Trains a neuronal network for image classification.
    Inspired from CNN-Image-Classifer by tatsuyah
    Copyright: tatsuyah
    link: https://github.com/tatsuyah/CNN-Image-Classifier/blob/master/src/predict-multiclass.py
    
    '''

    def train_cnn(self, dev=False):
        if dev:
            epochs = 2
        else:
            epochs = 20

        """
        Parameters
        """
        epochs = 20
        batch_size = 32
        print(str(self.img_height) + " " + str(self.img_width))
        validation_steps = 100
        nb_filters1 = 32
        nb_filters2 = 64
        conv1_size = 3
        conv2_size = 2
        pool_size = 2

        histogram_freq = 0
        lr = 0.0004

        model = Sequential()
        model.add(
            Convolution2D(nb_filters1, conv1_size, conv1_size, border_mode="same",
                          input_shape=(self.img_width, self.img_height, 3)))
        model.add(Activation("relu"))
        model.add(MaxPooling2D(pool_size=(pool_size, pool_size)))

        model.add(Convolution2D(nb_filters2, conv2_size, conv2_size, border_mode="same"))
        model.add(Activation("relu"))
        model.add(MaxPooling2D(pool_size=(pool_size, pool_size), dim_ordering='th'))

        model.add(Flatten())
        model.add(Dense(256))
        model.add(Activation("relu"))
        model.add(Dropout(0.5))
        model.add(Dense(self.classes_num, activation='softmax'))

        model.compile(loss='categorical_crossentropy',
                      optimizer=optimizers.RMSprop(lr=lr),
                      metrics=['accuracy'])

        train_datagen = ImageDataGenerator(
            rescale=1. / 255,
            shear_range=0.2,
            zoom_range=0.2,
            horizontal_flip=True)

        test_datagen = ImageDataGenerator(rescale=1. / 255)

        train_generator = train_datagen.flow_from_directory(
            self.train_data_path,
            target_size=(self.img_height, self.img_width),
            batch_size=batch_size,
            class_mode='categorical')

        validation_generator = test_datagen.flow_from_directory(
            self.validation_data_path,
            target_size=(self.img_height, self.img_width),
            batch_size=batch_size,
            class_mode='categorical')

        """
        Tensorboard log
        """
        log_dir = './tf-log/'
        tb_cb = callbacks.TensorBoard(log_dir=log_dir, histogram_freq=0)
        cbks = [tb_cb]

        model.fit_generator(
            train_generator,
            samples_per_epoch=self.samples_per_epoch,
            epochs=epochs,
            validation_data=validation_generator,
            callbacks=cbks,
            validation_steps=validation_steps)

        target_dir = './models/'
        if not os.path.exists(target_dir):
            os.mkdir(target_dir)
        model.save(self.model_path)
        model.save_weights(self.model_weights_path)
        del model

        clear_session()
        gc.collect()


class Test:
    def __init__(self, title, ratio, classes_num, height=180, width= 180):
        self.img_width, self.img_height = height, width
        self.model_path = './models/model.h5'
        self.model_weights_path = './models/weights.h5'
        self.title = title
        self.ratio = ratio
        self.classes_num = classes_num
        self.model = load_model(self.model_path)
        self.model.load_weights(self.model_weights_path)

    def predict(self, file):
        x = load_img(file, target_size=(self.img_width, self.img_height))
        x = img_to_array(x)
        x = np.expand_dims(x, axis=0)
        array = self.model.predict(x)
        result = array[0]
        answer = np.argmax(result)
        # print("answear " + str(answer))

        return answer

    def test_model(self, path):
        real_clf = []
        pred_clf = []
        correct_answer = 0
        wrong_answer = 0
        nr_images = 0
        with open('stats/' + self.title + '.txt', 'a') as f:
            dirList = get_the_list_of_subdirectories(path)
            i = 0
            for dir in dirList:

                img_collection = next(os.walk(path + '/' + dir))[2]
                for img in img_collection:
                    real_clf.append(i)
                    prediction = self.predict(path + '/' + dir + '/' + img)
                    pred_clf.append(prediction)
                    nr_images += 1
                    if prediction == i:
                        correct_answer += 1
                    else:
                        wrong_answer += 1
                i += 1
            print("accuracy " + str(correct_answer / nr_images * 100) + "%")
            f.write("real classes " + str(real_clf) + '\n')
            f.write(" predicted classes " + str(pred_clf) + '\n')
            f.write("accuracy " + str(correct_answer / nr_images * 100) + "%\n")
            cnf_matrix = confusion_matrix(pred_clf, real_clf)
            # plot_confusion_matrix(cm=cnf_matrix, classes=[])
            CNN.plot_confusion_matrix(cm=cnf_matrix, classes=dirList, normalize=True)
            plt.savefig("plots/" + self.title + "1.png")
            plt.close()
            del self.model
            self.model = None
            clear_session()


def push_to_git(files, title):


    repo_dir = './../'
    repo = Repo(repo_dir)

    commit_message = "added run " + title
    repo.index.add(files)
    repo.index.commit(commit_message)
    origin = repo.remote('origin')
    origin.push()


def limit_mem():
    K.get_session().close()
    cfg = K.tf.ConfigProto()
    cfg.gpu_options.allow_growth = True
    K.set_session(K.tf.Session(config=cfg))

def make_a_full_run(dataset_path, ratio=0.7, samples_per_epoch=5000, classes_num=10, height=180, width=180):
    title = "stats_self_made_r=" + str(ratio) + "n_" + str(classes_num) + "s_" + str(width)
    with open('stats/' + title + '.txt', 'a') as f:
        f.write(" \nStarting run for dataset from " + dataset_path + "\n  ratio: " + str(ratio) +
                "\n  classes num: " + str(classes_num) + "\n  samples per epoch  " + str(samples_per_epoch) + "\n")

    CNN.separate_into_train_and_test(path=dataset_path, ratio=ratio, categories_to_copy=classes_num)
    #print(str(width) + " " + str(height))
    cnn = CNN(classes_num=classes_num, samples_per_epoch=samples_per_epoch, width=width, height=height)
    t0 = time.time()
    cnn.train_cnn()
    t1 = time.time()


    test = Test(classes_num=classes_num, ratio=ratio, title=title, height=height, width=width)

    t2 = time.time()
    test.test_model(cnn.validation_data_path)

    t3 = time.time()
    with open('stats/' + title + '.txt', 'a') as f:
        f.write("train time " + str(t1 - t0) + "\n")
        f.write("test time " + str(t3 - t2) + "\n")

    shutil.rmtree(tmp_dir)
    limit_mem()
    push_to_git(['cnn/stats/' + title + '.txt',
                 "cnn/plots/" + title + "1.png"], title)
    shutil.rmtree('models')



if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('-r', '--ratio', type=float)
    parser.add_argument('-n', '--num', type=int)
    parser.add_argument('-s', '--samples', type=int)
    parser.add_argument('-he', '--height', type=int)
    parser.add_argument('-w', '--width', type=int)
    parser.add_argument("-p", "--path", type=str)
    args = parser.parse_args()

    ratio = 0.6
    classes_num = 10
    samples_per_epoch = 5000

    height = 180
    width = 180
    dataset_path = '../../datasets2/GHIM20'

    print(args)
    if args.ratio is not None:
        ratio = args.ratio
    if args.num is not None:
        classes_num = args.num
    if args.samples is not None:
        samples_per_epoch = args.samples
    if args.height is not None:
        height = args.height
    if args.width is not None:
        width = args.width
    if args.path is not None:
        dataset_path = args.path
    print("main " + dataset_path )
    make_a_full_run(dataset_path=dataset_path, ratio=ratio, samples_per_epoch=samples_per_epoch,
                    classes_num=classes_num, height=height, width=width)

