import os
import shutil

#from keras.preprocessing.image import ImageDataGenerator
#from keras.models import Sequential
#from keras.layers import Conv2D, MaxPooling2D
#from keras.layers import Activation, Dropout, Flatten, Dense
#from keras import backend as K
#import numpy as np

tmp_dir = "tmp"


# get the list of all dir in the parent
def get_the_list_of_subdirectories(parentPath):
    # get the list of folder names
    dirName = []
    for _, _dir, _ in os.walk(str(parentPath)):
        if len(_dir) > 0:
            dirName.append(_dir)
    return dirName[0]


'''
getting a dataset path, separates it into test and train, with the same folder names.
:param ratio default 0.7 
:param number of categories to be copied
'''


def separate_into_train_and_test(path, ratio=0.8, categories_to_copy=10):
    dirList = get_the_list_of_subdirectories(path)
    print(dirList)
    category_nr = 0
    for category in dirList:
        if category_nr == categories_to_copy:
            return
        train_dir = tmp_dir + '/train/' + category
        test_dir = tmp_dir + '/test/' + category

        try:
            os.stat(train_dir)
        except:
            os.makedirs(train_dir)
        try:
            os.stat(test_dir)
        except:
            os.makedirs(test_dir)

        imgCollection = next(os.walk(path + '/' + category))[2]
        nr_imgs = len(imgCollection)
        print(nr_imgs)
        for i in range(nr_imgs):

            if i < nr_imgs * ratio:
                source = path + "/" + category + "/" + imgCollection[i]

                dest = train_dir + "/" + imgCollection[i]
                shutil.copyfile(str(source), str(dest))
            else:
                source = path + "/" + category + "/" + imgCollection[i]
                dest = test_dir + "/" + imgCollection[i]
                shutil.copyfile(str(source), str(dest))


            category_nr += 1

separate_into_train_and_test(path="../../datasets2/GHIM20", categories_to_copy=20, ratio=0.1)

# dimensions of our images.

'''
img_width, img_height = 400, 400

train_data_dir = './tmp/train/'
validation_data_dir = './tmp/test/'
nb_train_samples = 2000
nb_validation_samples = 800
epochs = 10
batch_size = 16

if K.image_data_format() == 'channels_first':
    input_shape = (3, img_width, img_height)
else:
    input_shape = (img_width, img_height, 3)

model = Sequential()
model.add(Conv2D(32, (3, 3), input_shape=input_shape))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(32, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(64, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Flatten())
model.add(Dense(64))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(1))
model.add(Activation('sigmoid'))

model.compile(loss='binary_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])

# this is the augmentation configuration we will use for training
train_datagen = ImageDataGenerator(
    rescale=1. / 255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True)

# this is the augmentation configuration we will use for testing:
# only rescaling
test_datagen = ImageDataGenerator(rescale=1. / 255)

train_generator = train_datagen.flow_from_directory(
    train_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='binary')

validation_generator = test_datagen.flow_from_directory(
    validation_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='binary')

model.fit_generator(
    train_generator,
    steps_per_epoch=nb_train_samples // batch_size,
    epochs=epochs,
    validation_data=validation_generator,
    validation_steps=nb_validation_samples // batch_size)

model.save_weights('first_try.h5')

'''
