import time
from shutil import copyfile

import os

import scipy
from sklearn.ensemble import AdaBoostClassifier
from sklearn.externals import joblib
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC, LinearSVC
import cv2
from sklearn.tree import DecisionTreeClassifier

import descriptors
import shutil

import BOVW


class Runner:
    def __init__(self):
        self.logger = "logger.txt"
        self.tmp_dir = "tmp"
        self.descriptor = descriptors.SurfHelper()
        self.clfs = []
        self.add_classifiers()
        self.nr_clusters = []
        self.datasets = []
        self.probabilities = []
        # self.add_cluster()
        self.descriptors = []
        self.add_descriptors()
        self.test_descriptor = descriptors.SurfHelper(hessianThreshold=500)
        self.ratio = 0

    def run(self, dataset, nr_categories=0):
        accuracy = []
        time_took = []
        test_time = []
        with open('stats2/' + dataset + '.txt', 'ab') as f:
            f.write("Starting run for dataset: " + str(dataset) + "  nr of categories: " + str(nr_categories) + "\n")
            for descriptor in self.descriptors:
                f.write("using descriptor:" + str(descriptor) + "\n")
                nr_cls = nr_categories * 30
                if str(dataset) == "ghim20_ratio3":
                    nr_cls *= 2
                f.write("using nr of clusters:" + str(nr_cls) + "\n")
                for clf in self.clfs:
                    f.write("Using classifier " + str(clf) + '\n')

                    t0 = time.time()
                    bov = BOVW.BOVW(no_clusters=nr_cls, descriptor=descriptor, clf=clf, output=f)
                    bov.run_name = dataset + self.ratio + str(nr_categories)
                    bov.test_path = self.tmp_dir + "/test/"
                    bov.train_path = self.tmp_dir + "/train/"

                    bov.trainModel()

                    t1 = time.time()
                    time_took.append(t1 - t0)
                    f.write("to train took " + str(t1 - t0) + '\n')

                    accuracy.append(bov.testModel())

                    t2 = time.time()
                    bov.output.write("testing took" + str(t2 - t1) + '\n')
                    # bov.descriptor = self.test_descriptor

                    test_time.append(t2 - t1)

                f.write("accuracy: " + str(accuracy) + '\n')
                f.write("time: " + str(time_took) + '\n')
                f.write("test time: " + str(test_time) + '\n')

    '''
    :param  path to dataset
    :param runs, list with the nr of desired categories, length of this array will determine the nr runs
    '''

    def prepare_dataset(self, path, runs, dataset, ratio=0.7):
        for run in runs:
            os.mkdir(self.tmp_dir)
            self.separate_into_train_and_test(path=path, categories_to_copy=run, ratio=ratio)

            self.run(dataset, nr_categories=run)
            shutil.rmtree(self.tmp_dir)

    '''
    :param  path to dataset
    :param runs, list with the nr of desired categories, length of this array will determine the nr runs
    '''

    def prepare_dataset_resize(self, path, runs, dataset, ratio=0.7, resize_ratio=0.5):
        for run in runs:
            os.mkdir(self.tmp_dir)
            self.separate_into_train_and_test_and_resize(path=path, categories_to_copy=run, ratio=ratio,
                                                         resize_ratio=resize_ratio)

            self.run(dataset, nr_categories=run)
            shutil.rmtree(self.tmp_dir)

    # get the list of all dir in the parent
    def get_the_list_of_subdirectories(self, parentPath):
        # get the list of folder names
        dirName = []
        for _, _dir, _ in os.walk(str(parentPath)):
            if len(_dir) > 0:
                dirName.append(_dir)
        return dirName[0]

    '''
    getting a dataset path, separates it into test and train, with the same folder names.
    :param ratio default 0.7 
    :param number of categories to be copied
    '''

    def separate_into_train_and_test(self, path, ratio=0.2, categories_to_copy=10):
        self.ratio = "ratio" + str(ratio)
        dirList = self.get_the_list_of_subdirectories(path)
        print dirList
        category_nr = 0
        for category in dirList:
            if category_nr == categories_to_copy:
                return
            train_dir = self.tmp_dir + '/train/' + category
            test_dir = self.tmp_dir + '/test/' + category

            try:
                os.stat(train_dir)
            except:
                os.makedirs(train_dir)
            try:
                os.stat(test_dir)
            except:
                os.makedirs(test_dir)

            imgCollection = next(os.walk(path + '/' + category))[2]
            nr_imgs = len(imgCollection)
            print nr_imgs
            for i in range(nr_imgs):
                if i < nr_imgs * ratio:
                    source = path + "/" + category + "/" + imgCollection[i]
                    dest = train_dir + "/" + imgCollection[i]
                    copyfile(str(source), str(dest))
                else:
                    source = path + "/" + category + "/" + imgCollection[i]
                    dest = test_dir + "/" + imgCollection[i]
                    copyfile(str(source), str(dest))
            category_nr += 1

    def separate_into_train_and_test_and_resize(self, path, ratio=0.2, categories_to_copy=10, resize_ratio=0.5):
        self.ratio = "ratio" + str(ratio)
        dirList = self.get_the_list_of_subdirectories(path)
        print dirList
        category_nr = 0
        for category in dirList:
            if category_nr == categories_to_copy:
                return
            train_dir = self.tmp_dir + '/train/' + category
            test_dir = self.tmp_dir + '/test/' + category

            try:
                os.stat(train_dir)
            except:
                os.makedirs(train_dir)
            try:
                os.stat(test_dir)
            except:
                os.makedirs(test_dir)

            imgCollection = next(os.walk(path + '/' + category))[2]
            nr_imgs = len(imgCollection)
            print nr_imgs
            for i in range(nr_imgs):
                if i < nr_imgs * ratio:
                    source = path + "/" + category + "/" + imgCollection[i]
                    dest = train_dir + "/" + imgCollection[i]
                    image = cv2.imread(source)
                    small = cv2.resize(image, (0, 0), fx=resize_ratio, fy=resize_ratio)
                    cv2.imwrite(dest, small)
                else:
                    source = path + "/" + category + "/" + imgCollection[i]
                    dest = test_dir + "/" + imgCollection[i]
                    image = cv2.imread(source)
                    small = cv2.resize(image, (0, 0), fx=resize_ratio, fy=resize_ratio)
                    cv2.imwrite(dest, small)
            category_nr += 1

    def add_classifiers(self):
        self.clfs.append(SVC(decision_function_shape='ovo'))
        #self.clfs.append(MLPClassifier())
        # self.clfs.append(KNeighborsClassifier())
        # self.clfs.append(GaussianNB())

    def add_datasets(self):
        self.datasets.append("../datasets/corel/")
        self.datasets.append("../datasets/GHIM/")

    def add_cluster(self):
        self.nr_clusters.append(100)

    def add_descriptors(self):
        self.descriptors.append(descriptors.SurfHelper(hessianThreshold=600))
        #elf.descriptors.append(descriptors.SurfHelper(upright=False))
        #self.descriptors.append(descriptors.Sift())
        #self.descriptors.append(descriptors.Brief())
        #self.descriptors.append(descriptors.Orb())


if __name__ == '__main__':
    runner = Runner()

    runner.prepare_dataset("../self_made_dataset/", [10], "self_made")

    # runner.prepare_dataset("../datasets2/corel-categories/", [5], "corel_des3")
    # runner.prepare_dataset("../datasets2/caltech_101/", [5], "caltech_101_des3")
    # runner.prepare_dataset("../datasets2/caltech_256/", [5], "caltech_256_des3")
    # runner.prepare_dataset("../datasets2/GHIM20/", [ 5], "ghim20_des4")
    # runner.prepare_dataset("../datasets2/corel-categories/", [10, 20], "corel_des_sift")
    # runner.prepare_dataset("../datasets2/caltech_101/", [30], "caltech_101_clf")

    # runner.prepare_dataset("../datasets/corel/", [5], "corel_dataset")
    # runner.prepare_dataset("../datasets/corel/", [10], "corel_dataset")
    # runner.prepare_dataset("../datasets/corel/", [20], "corel_dataset")
    '''
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [3], "ghim20_dim", resize_ratio=0.2)
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [3], "ghim20_dim", resize_ratio=0.4)
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [3], "ghim20_dim", resize_ratio=0.5)
    runner.prepare_dataset("../datasets2/GHIM20/", [3], "ghim20_dim")
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [5], "ghim20_dim", resize_ratio=0.2)
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [5], "ghim20_dim", resize_ratio=0.4)
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [5], "ghim20_dim", resize_ratio=0.5)
    runner.prepare_dataset("../datasets2/GHIM20/", [5], "ghim20_dim")
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [10], "ghim20_dim", resize_ratio=0.2)
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [10], "ghim20_dim", resize_ratio=0.4)
    runner.prepare_dataset_resize("../datasets2/GHIM20/", [10], "ghim20_dim", resize_ratio=0.5)
    runner.prepare_dataset("../datasets2/GHIM20/", [10], "ghim20_dim")

    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_diff", ratio=0.4)
    runner.prepare_dataset("../datasets/GHIM2/", [3], "ghim20_diff", ratio=0.6)
    runner.prepare_dataset("../datasets/GHIM/", [5], "ghim20_diff", ratio=0.4)
    runner.prepare_dataset("../datasets/GHIM2/", [5], "ghim20_diff", ratio=0.6)
    runner.prepare_dataset("../datasets/GHIM/", [10], "ghim20_diff", ratio=0.4)
    runner.prepare_dataset("../datasets/GHIM2/", [10], "ghim20_diff", ratio=0.6)
    
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.01)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.05)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.1)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.2)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.3)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.4)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.5)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.6)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.7)
    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_ratio3", ratio=0.8)

    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.01)
    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.05)
    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.1)
    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.3)
    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.4)
    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.5)
    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.6)
    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.7)
    runner.prepare_dataset("../datasets2/corel-categories/", [10], "corel_ratio3", ratio=0.8)
   

    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_last_des", ratio=0.8)
    runner.prepare_dataset("../datasets2/caltech_256/", [20], "caltech_256_last_des", ratio=0.8)

    runner.prepare_dataset("../datasets/GHIM/", [3], "ghim20_test", ratio=0.5)

    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.05)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.1)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.2)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.3)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.4)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.5)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.6)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.7)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_ratio3", ratio=0.8)

    runner.prepare_dataset("../datasets/GHIM/", [5], "ghim20_ratio3", ratio=0.7)
    runner.prepare_dataset("../datasets/GHIM/", [10], "ghim20_ratio3", ratio=0.7)

    runner.prepare_dataset("../datasets2/caltech_256/", [5], "caltech_256_plt", ratio=0.8)
    runner.prepare_dataset("../datasets2/caltech_256/", [10], "caltech_256_plt", ratio=0.8)
    runner.prepare_dataset("../datasets2/caltech_256/", [50], "caltech_256_fin")
    runner.prepare_dataset("../datasets2/corel-categories/", [50], "corel_fin")
    runner.prepare_dataset("../datasets2/caltech_101/", [50], "caltech_101_fin")
    runner.prepare_dataset("../datasets2/GHIM20/", [20], "ghim20_2f")
    runner.prepare_dataset("../datasets2/caltech_256/", [100, 200, 256], "caltech_256_fin")
    runner.prepare_dataset("../datasets2/caltech_101/", [101], "caltech_101_fin")
    '''