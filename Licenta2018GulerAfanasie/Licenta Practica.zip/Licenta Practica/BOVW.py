import itertools
import time
from glob import glob

import cv2
import numpy as np
from configobj import ConfigObj
from matplotlib import pyplot as plt
from sklearn.externals import joblib


import classifier
import descriptors
from sklearn.metrics import confusion_matrix


class FileHelpers:
    def __init__(self):
        pass

    def getFiles(self, path):

        imlist = {}
        count = 0
        for each in glob(path + "*"):
            word = each.split("/")[-1]

            imlist[word] = []
            for imagefile in glob(path + word + "/*"):
                im = cv2.imread(imagefile, 0)
                imlist[word].append(im)
                count += 1

        return [imlist, count]


def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


def show_sift_features(gray_img, color_img, kp):
    return plt.imshow(cv2.drawKeypoints(gray_img, kp, color_img.copy()))


class BOVW:
    def __init__(self, no_clusters, descriptor, clf, output):
        self.no_clusters = no_clusters
        self.train_path = None
        self.test_path = None
        self.good_guesses = 0
        self.classifier = classifier.BOVHelpers(n_clusters=no_clusters, clf=clf)
        self.file_helper = FileHelpers()
        self.images = None
        self.trainImageCount = 0
        self.train_labels = np.array([])

        self.descriptor_list = []


        self.descriptor = descriptor
        self.output = output

    def trainModel(self):

        self.images, self.trainImageCount = self.file_helper.getFiles(self.train_path)
        # extract  Features from each image
        label_count = 0
        for word, imlist in self.images.iteritems():
            self.classifier.name_dict[str(label_count)] = word
            print "Computing Features for ", word, label_count
            for im in imlist:

                self.train_labels = np.append(self.train_labels, label_count)
                kp, des = self.descriptor.features(im)
                if des is not None:
                    self.descriptor_list.append(des)

            label_count += 1
        # print self.descriptor_list
        print("start clustering")
        # perform clustering
        self.classifier.formatND(self.descriptor_list)

        self.classifier.cluster()
        print "start classifying"
        self.classifier.develop_vocabulary(n_images=self.trainImageCount, descriptor_list=self.descriptor_list)

        # show vocabulary trained
        # self.classifier.plotHist()

        self.classifier.standardize()

        return self.classifier.train(self.train_labels)

    def recognize(self, test_img, test_image_path=None, image_classification=1):

        kp, des = self.descriptor.features(test_img)
        vocab = np.array([[0 for i in range(self.no_clusters)]])

        test_ret = self.classifier.kmeans_obj.predict(des)
        for each in test_ret:
            vocab[0][each] += 1
        vocab2 = self.classifier.scale.transform(vocab)
        lb = self.classifier.clf.predict(vocab2)
        #predict = self.classifier.clf.predict_proba(vocab2)
        # print predict
        #max_prob = 0
        #max_prob_index = 0
        #for i in range(0, len(predict[0])):
        #    if predict[0][i] > max_prob:
        #        max_prob = predict[0][i]
        #        max_prob_index = i
        # print "max, predicted, max prob", max_prob_index, lb[0], image_classification
        #if max_prob_index == int(image_classification):
         #   self.good_guesses += 1
            # print "Image belongs to class : ", self.name_dict[str(int(lb[0]))], "with prob", predict[0][int(lb[0])]

            # print "Image actually belongs to", self.name_dict[str(int(image_classification))], "with prob", predict[0][
        #    int(image_classification)]

        return lb

    def testModel(self):

        self.testImages, self.testImageCount = self.file_helper.getFiles(self.test_path)

        predictions = []
        idx = 0
        for word, imlist in self.testImages.iteritems():
            # print "processing ", word
            for im in imlist:
                # print imlist[0].shape, imlist[1].shape
                # print im.shape
                try:
                    cl = self.recognize(im, image_classification=idx)
                except:
                    print("the descriptor failed to detect any features, classifying as first class")
                    cl = [0]
                # print cl
                predictions.append({
                    'real_classification': idx,
                    'image': im,
                    'class': cl,
                    'object_name': self.classifier.name_dict[str(int(cl[0]))]
                })
            idx += 1

        y_test = [0] * len(predictions)
        y_pred = [0] * len(predictions)

        # print predictions
        correct_answers = 0
        idx = 0
        for each in predictions:

            if each['class'] == each['real_classification']:
                correct_answers += 1
            y_pred[idx] = each['class']
            y_test[idx] = each['real_classification']
            idx += 1
        a = [0] * len(self.classifier.name_dict)
        for i in range(len(a)):
            a[i] = self.classifier.name_dict[str(i)]

        self.output.write("Guessing rate: " + str(correct_answers) + "/" + str(len(predictions)) + "\n")
        self.output.write(" rate % :" + str(((correct_answers * 1.0) / len(predictions) * 100)) + "\n")

        cnf_matrix = confusion_matrix(y_test, y_pred)
        np.set_printoptions(precision=2)

        class_names = a
        # Plot non-normalized confusion matrix
        plt.figure()
        plot_confusion_matrix(cnf_matrix, classes=class_names,
                            title='Confusion matrix, without normalization')
        plt.savefig("plots/" + self.run_name + ".png")
        plt.close()
        # Plot normalized confusion matrix
        plt.figure()
        plot_confusion_matrix(cnf_matrix, classes=class_names, normalize=True,
                            title='Normalized confusion matrix')

        plt.savefig("plots/" + self.run_name + "1.png")
        plt.close()
        #plt.show()
        #print "taking the option with most of % rate", (self.good_guesses * 1.0) / len(predictions) * 100, "%"
        #for i in range(0, len(self.classifier.name_dict)):
        #    a[i] = self.classifier.name_dict[str(i)]
        #    print i, self.classifier.name_dict[str(i)]
        return ((correct_answers * 1.0) / len(predictions) * 100)

if __name__ == '__main__':
    config = ConfigObj('config')

    t0 = time.time()
    surf_helper = descriptors.SurfHelper(hessianThreshold=2000)
    brief_helper = descriptors.Brief()
    freak_helper = descriptors.FreakHelper()

    sift_helper = descriptors.Sift()
    orb_helper = descriptors.Orb()
    fast_helper = descriptors.FastHelper()
    bov = BOVW(no_clusters=200, descriptor=surf_helper)
    bov.test_path = '../coreldataset/test/'
    bov.train_path = '../coreldataset/train/'

    bov.trainModel()
    
    joblib.dump(bov.classifier, 'trained_models/classifier.pkl')

    '''

    classifier = joblib.load('trained_models/classifier.pkl')
    bov.classifier = classifier
    '''

    t1 = time.time()
    bov.output.write("to train took " + str(t1 - t0))

    bov.testModel()
    t2 = time.time()
    bov.output.write("testing took" + str(t2 - t1))
