from pathlib import Path
from six.moves import xrange
import os as os
from shutil import copyfile
import random




# get the list of all dir in the parent
def getTheListOfSubDirectories(parentPath):
    # get the list of folder names
    dirName = []
    for _, _dir, _ in os.walk(str(parentPath)):
        if len(_dir) > 0:
            dirName.append(_dir)
    return dirName[0]




if __name__ == "__main__":
    ratio = 0.7
    where_the_photos_are = "../datasets/corel"
    where_to_copy = '../coreldataset'
    dirList = getTheListOfSubDirectories(where_the_photos_are)
    print dirList
    for category in dirList:

        train_dir = where_to_copy + '/train/' + category
        test_dir = where_to_copy + '/test/' + category

        try:
            os.stat(train_dir)
        except:
            os.makedirs(train_dir)
        try:
            os.stat(test_dir)
        except:
            os.makedirs(test_dir)

        imgCollection = next(os.walk(where_the_photos_are + '/' + category))[2]
        nr_imgs = len(imgCollection)
        print nr_imgs
        for i in range(nr_imgs):
            if i < nr_imgs * 0.7:
                source = where_the_photos_are + "/" + category + "/" + imgCollection[i]
                dest = train_dir + "/" + imgCollection[i]
                print("Completed --> ", copyfile(str(source), str(dest)))
            else:
                source = where_the_photos_are + "/" + category + "/" + imgCollection[i]
                dest = test_dir + "/" + imgCollection[i]
                print("Completed --> ", copyfile(str(source), str(dest)))









