import matplotlib.pyplot as plt
import numpy as np

# GHIM plot, data took from stats2/ghim20_ratio2
'''
fig, ax1 = plt.subplots()

x = np.array([5, 25, 50, 100, 150, 200, 250, 300, 350, 400])
y1 = [79.93, 87.08, 89.48, 92.83, 94.1, 95.0, 95.19, 95.16, 95.77, 96]
ax1.plot(x, y1, c='b')
ax1.scatter(x, y1, s=100, c='b')
ax1.set_xlabel('poze antrenament per categorie')
ax1.set_ylabel('acuratete (%)', color='b')
ax1.tick_params('y', colors='b')

ax2 = ax1.twinx()
y2 = [11.6, 112.57, 280.11, 726.25, 1289.52, 1972.64, 2423.32, 2884.28, 3339.65, 3739.01]
ax2.plot(x, y2, c='r')
ax2.scatter(x, y2, c='r', s=100)
ax2.set_ylabel('timp antrenare (s)', color='r')
ax2.tick_params('y', colors='r')

fig.tight_layout()
plt.show()

# corel plot for seeing accuracy based on nr of train images, stats2/corel_ratio2
fig, ax1 = plt.subplots()

x = np.array([1, 5, 10, 30, 40, 50, 60, 70, 80])
y1 = [26.36, 46.42, 49., 55.85, 59.67, 61.2, 62.75, 63., 69.]
ax1.plot(x, y1, c='b')
ax1.scatter(x, y1, s=100, c='b')
ax1.set_xlabel('poze antrenament per categorie')
ax1.set_ylabel('acuratete (%)', color='b')
ax1.tick_params('y', colors='b')

ax2 = ax1.twinx()
y2 = [1.73, 6.3, 13.98, 73.11, 125.18, 154.72, 235.09, 299.78, 341.32]
ax2.plot(x, y2, c='r')
ax2.scatter(x, y2, c='r', s=100)
ax2.set_ylabel('timp antrenare (s)', color='r')
ax2.tick_params('y', colors='r')

fig.tight_layout()
plt.show()


# caltech_256 plot for seeing accuracy based on nr of train images, stats2/caltech_256_ratio2
fig, ax1 = plt.subplots()

x = np.array([6, 12, 24, 36, 48, 60, 72, ])
y1 = [33.39, 38.99, 44.51 ]
ax1.plot(x, y1, c='b')
ax1.scatter(x, y1, s=100, c='b')
ax1.set_xlabel('poze antrenament per categorie')
ax1.set_ylabel('acuratete (%)', color='b')
ax1.tick_params('y', colors='b')

ax2 = ax1.twinx()
y2 = [131.57,357.87, ]
ax2.plot(x, y2, c='r')
ax2.scatter(x, y2, c='r', s=100)
ax2.set_ylabel('timp antrenare (s)', color='r')
ax2.tick_params('y', colors='r')

fig.tight_layout()
plt.show()
'''


figure = plt.figure()

#ghim resize plot 3

fig, ax1 = plt.subplots()

x = np.array([0.2 ,0.4, 0.5, 1.0])
y1 = [ 76.88, 85.22 ,88.9, 96.]
ax1.plot(x, y1, c='b')
ax1.scatter(x, y1, s=100, c='b')
ax1.set_xlabel('indice de redimensionare')
ax1.set_ylabel('acuratete (%)', color='b')
ax1.tick_params('y', colors='b')

ax2 = ax1.twinx()
y2 = [11.36, 75.09, 120.82, 658.93]
ax2.plot(x, y2, c='r')
ax2.scatter(x, y2, c='r', s=100)
ax2.set_ylabel('timp antrenare (s)', color='r')
ax2.tick_params('y', colors='r')


fig.tight_layout()
plt.show()



#ghim resize 5 categories
fig, ax1 = plt.subplots()

x = np.array([0.2 ,0.4, 0.5, 1.0])
y1 = [ 57.2, 69.46, 73.46, 82.8 ]
ax1.plot(x, y1, c='b')
ax1.scatter(x, y1, s=100, c='b')
ax1.set_xlabel('indice de redimensionare')
ax1.set_ylabel('acuratete (%)', color='b')
ax1.tick_params('y', colors='b')

ax2 = ax1.twinx()
y2 = [35.87, 358.2, 589.19, 3193.15]
ax2.plot(x, y2, c='r')
ax2.scatter(x, y2, c='r', s=100)
ax2.set_ylabel('timp antrenare (s)', color='r')
ax2.tick_params('y', colors='r')

fig.tight_layout()
plt.show()

#ghim resize 10 categories
fig, ax1 = plt.subplots()

x = np.array([0.2 ,0.4, 0.5, 1.0])
y1 = [42.2, 54.33, 59.4, 70.8  ]
ax1.plot(x, y1, c='b')
ax1.scatter(x, y1, s=100, c='b')
ax1.set_xlabel('indice de redimensionare')
ax1.set_ylabel('acuratete (%)', color='b')
ax1.tick_params('y', colors='b')

ax2 = ax1.twinx()
y2 = [225.55, 2472.27, 3766.23, 15679.61]
ax2.plot(x, y2, c='r')
ax2.scatter(x, y2, c='r', s=100)
ax2.set_ylabel('timp antrenare (s)', color='r')
ax2.tick_params('y', colors='r')

fig.tight_layout()

plt.show()