import os as os
from shutil import copyfile



pace = 500
where_the_photos_are = "../GHIM20"
where_to_copy = '../datasets2/GHIM20'

imgCollection = next(os.walk(where_the_photos_are))[2]
nr_imgs = len(imgCollection)
current_path = where_to_copy

for i in range(1,10001):

    if (i - 1) % pace == 0:
        if not os.path.exists(where_to_copy + '/' + str((i - 1) / pace) + '/'):
            os.makedirs(where_to_copy + '/' + str((i - 1) / pace) + '/')

        current_path = where_to_copy + '/' + str((i - 1) / pace) + '/'

    source = where_the_photos_are + "/" + str(i) + ".jpg"
    dest = current_path + str(i) + ".jpg"
    print dest
    print("Completed --> ", copyfile(str(source), str(dest)))







