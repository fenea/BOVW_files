import cv2

img = cv2.imread("image_0040.jpg")
height, width, chanels = img.shape
print (height, width)
if height>width:
    new_image = img[0:width, 0:width]
else:
    new_image = img[0:height , 0:height]

cv2.imshow("cropped", new_image)
cv2.waitKey(0)
print(new_image.shape)