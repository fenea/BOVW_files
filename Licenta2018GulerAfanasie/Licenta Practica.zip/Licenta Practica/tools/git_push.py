
import git
from git import Git, Repo


def push_to_git(files, title):
    Git.refresh(path="C:\Program Files\Git\cmd\git.exe")

    repo_dir = './'
    repo = Repo(repo_dir)

    commit_message = "added run " + title
    repo.index.add(files)
    repo.index.commit(commit_message)
    origin = repo.remote('origin')
    origin.push()

if __name__ == "__main__":
    push_to_git(["cnn/stats/stats3.txt"], "pushed stats 3")